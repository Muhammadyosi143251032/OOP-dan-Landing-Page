<?php
class Wisata {
    public function getWisata() {
        return [
            [
                "nama" => "Mt. Fuji & Tokyo Discovery", 
                "harga" => "Rp 25.000.000 / pax", 
                "fasilitas" => "Tiket Pesawat PP, Hotel Bintang 4, Transportasi, & Makan 3x Sehari",
                "gambar" => "Screenshot 2026-05-09 153458.png"
            ],
            [
                "nama" => "Kyoto Autumn Heritage", 
                "harga" => "Rp 20.000.000 / pax", 
                "fasilitas" => "Tiket Pesawat PP, Ryokan Tradisional, Transportasi, & Makan 3x Sehari",
                "gambar" => "Screenshot 2026-05-09 154142.png"
            ],
            [
                "nama" => "Asian Marvels: SG Explorer", 
                "harga" => "Rp 15.000.000 / pax", 
                "fasilitas" => "Tiket Pesawat PP, Hotel Bintang 4, Transportasi MRT, & Makan 3x Sehari",
                "gambar" => "Screenshot 2026-05-09 154028.png"
            ],
            [
                "nama" => "Great Wall & East Asia", 
                "harga" => "Rp 30.000.000 / pax", 
                "fasilitas" => "Tiket Pesawat PP, Hotel Bintang 5, Transportasi VIP, & Makan 3x Sehari",
                "gambar" => "Screenshot 2026-05-09 153806.png"
            ]
        ];
    }
}