<?php
class HomeController extends Controller {
    public function index() {
        $wisataModel = $this->model("Wisata");
        $data["wisata"] = $wisataModel->getWisata();
        
        $this->view("home", $data);
    }
}