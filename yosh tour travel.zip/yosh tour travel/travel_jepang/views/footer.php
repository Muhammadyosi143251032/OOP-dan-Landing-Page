<footer class="footer">
    <div class="footer-container">
        <div class="footer-col">
            <div class="brand">
                <img src="assets/images/Screenshot 2026-05-09 154412.png" alt="Logo Travel">
                <h3>Nippon Vibes</h3>
            </div>
            <p>Biro perjalanan terpercaya untuk menjelajahi keajaiban budaya Jepang dan panorama Asia Timur.</p>
        </div>
        <div class="footer-col">
            <h4>Hubungi Kami</h4>
            <p><i class="fas fa-map-marker-alt"></i> Tokyo, Japan / Bondowoso, ID</p>
            <p><i class="fas fa-phone"></i> 0812-TRAVEL-JP</p>
            <p><i class="fas fa-envelope"></i> muhammadyosi2704@gmail.com</p>
        </div>
        <div class="footer-col">
            <h4>Ikuti Perjalanan Kami</h4>
            <div class="social">
                <a href="#"><i class="fab fa-instagram"></i> Instagram</a>
                <a href="#"><i class="fab fa-facebook"></i> Facebook</a>
                <a href="#"><i class="fab fa-tiktok"></i> TikTok</a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2026 Nippon Vibes Travel | Merajut Kenangan Tak Terlupakan</p>
    </div>
</footer>

<script>
    // Efek Navbar saat di-scroll
    const nav = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        nav.classList.toggle('scrolled', window.scrollY > 50);
    });
</script>
</body>
</html>