<?php $wisata = $wisata ?? []; ?>

<nav id="navbar">
    <div class="nav-logo">
        <img src="assets/images/Screenshot 2026-05-09 163054.png" alt="Logo Travel">
        <span>Yosh Tour Travel</span>
    </div>
    <ul class="nav-links">
        <li><a href="#about">Tentang Kami</a></li>
        <li><a href="#katalog">Paket Wisata</a></li>
        <li><a href="#pesan" class="btn-nav">Pesan Sekarang</a></li>
    </ul>
</nav>

<section class="hero">
    <div class="overlay"></div>
    <div class="hero-content">
        <h1>Jelajahi Keindahan Asia</h1>
        <p>Rasakan nuansa otentik Jepang dan pesona Asia lainnya dengan kenyamanan kelas satu.</p>
        <div class="hero-btn">
            <a href="#katalog" class="btn-primary">Lihat Destinasi</a>
        </div>
    </div>
</section>

<section class="about" id="about">
    <div class="about-container">
        <div class="about-text">
            <h2>Tentang Nippon Vibes</h2>
            <div class="divider"></div>
            <p>Kami hadir untuk mewujudkan liburan impianmu. Dengan layanan profesional *all-in* (Tiket, Hotel, Transportasi, & Makan), kamu hanya perlu membawa koper dan menikmati momen. Jelajahi keindahan budaya, alam, dan kuliner otentik bersama panduan ahli kami.</p>
        </div>
        <div class="about-img">
            <img src="assets/images/Screenshot 2026-05-09 154412.png" alt="Nippon Vibes Logo">
        </div>
    </div>
</section>

<section class="menu" id="katalog">
    <h2>Paket Perjalanan Spesial</h2>
    <div class="divider mx-auto"></div>
    <div class="grid">
        <?php foreach($wisata as $w): ?>
        <div class="card">
            <div class="card-img">
                <img src="assets/images/<?= $w['gambar']; ?>" alt="<?= $w['nama']; ?>">
            </div>
            <div class="card-body">
                <h3><?= $w['nama']; ?></h3>
                <p class="price"><?= $w['harga']; ?></p>
                <div class="fasilitas">
                    <i class="fas fa-check-circle"></i>
                    <p><?= $w['fasilitas']; ?></p>
                </div>
                <a href="#pesan" class="btn-card">Pilih Paket</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="booking" id="pesan">
    <div class="booking-container">
        <div class="booking-text">
            <h2>Mulai Petualanganmu</h2>
            <p>Pesan sekarang dan biarkan tim kami mengurus semua keperluan perjalananmu dari awal hingga pulang.</p>
        </div>
        <form class="booking-form" action="https://formsubmit.co/rulove857@gmail.com" method="POST">
            <input type="hidden" name="_subject" value="Pemesanan Baru: Nippon Vibes Travel!">
            <input type="text" name="Nama_Lengkap" placeholder="Nama Lengkap Pemesan" required>
            <input type="email" name="Email" placeholder="Alamat Email" required>
            
            <select name="Paket_Pilihan" required>
                <option value="" disabled selected>Pilih Paket Destinasi...</option>
                <?php foreach($wisata as $w): ?>
                    <option value="<?= $w['nama']; ?>"><?= $w['nama']; ?> - <?= $w['harga']; ?></option>
                <?php endforeach; ?>
            </select>
            
            <input type="number" name="Jumlah_Peserta" placeholder="Jumlah Peserta" min="1" required>
            <input type="date" name="Tanggal_Keberangkatan" required>
            <button type="submit">Konfirmasi Pemesanan</button>
        </form>
    </div>
</section>